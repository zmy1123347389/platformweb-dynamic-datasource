CREATE TABLE `lawapp_picture_info` (
  `ID` varchar(32) NOT NULL,
  `TITLE_DES` varchar(100) NOT NULL COMMENT '标题描述',
  `PICTURE_ADDRESS` varchar(100) DEFAULT NULL COMMENT '图片地址',
  `REMARK` varchar(100) DEFAULT NULL COMMENT '备注',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '创建时间',
  `CREATE_BY` varchar(32) DEFAULT NULL COMMENT '创建人',
  `UPDATED_TIME` datetime DEFAULT NULL COMMENT '更新时间',
  `UPDATED_BY` varchar(32) DEFAULT NULL COMMENT '更新人',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='漫画图片表 '
