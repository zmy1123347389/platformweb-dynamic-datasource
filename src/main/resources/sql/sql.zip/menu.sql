/*
SQLyog Ultimate - MySQL GUI v8.2 
MySQL - 5.5.27 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `sys_menu` (
	`menu_id` double ,
	`parent_id` double ,
	`name` varchar (150),
	`url` varchar (600),
	`perms` varchar (1500),
	`type` double ,
	`icon` varchar (150),
	`order_num` double ,
	`gmt_create` datetime ,
	`gmt_modified` datetime 
); 
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('2','3','系统菜单','sys/menu/','sys:menu:menu','1','fa fa-th-list','2','2017-08-09 22:55:15',NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('3','0','系统管理',NULL,NULL,'0','fa fa-desktop','1','2017-08-09 23:06:55','2017-08-14 14:13:43');
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('6','3','用户管理','sys/user/','sys:user:user','1','fa fa-user','0','2017-08-10 14:12:11',NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('7','3','角色管理','sys/role','sys:role:role','1','fa fa-paw','1','2017-08-10 14:13:19',NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('12','6','新增','','sys:user:add','2','','0','2017-08-14 10:51:35',NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('13','6','编辑','','sys:user:edit','2','','0','2017-08-14 10:52:06',NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('14','6','删除',NULL,'sys:user:remove','2',NULL,'0','2017-08-14 10:52:24',NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('15','7','新增','','sys:role:add','2','','0','2017-08-14 10:56:37',NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('20','2','新增','','sys:menu:add','2','','0','2017-08-14 10:59:32',NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('21','2','编辑','','sys:menu:edit','2','','0','2017-08-14 10:59:56',NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('22','2','删除','','sys:menu:remove','2','','0','2017-08-14 11:00:26',NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('24','6','批量删除','','sys:user:batchRemove','2','','0','2017-08-14 17:27:18',NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('25','6','停用',NULL,'sys:user:disable','2',NULL,'0','2017-08-14 17:27:43',NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('26','6','重置密码','','sys:user:resetPwd','2','','0','2017-08-14 17:28:34',NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('27','91','系统日志','common/log','common:log','1','fa fa-warning','0','2017-08-14 22:11:53',NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('28','27','刷新',NULL,'sys:log:list','2',NULL,'0','2017-08-14 22:30:22',NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('29','27','删除',NULL,'sys:log:remove','2',NULL,'0','2017-08-14 22:30:43',NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('30','27','清空',NULL,'sys:log:clear','2',NULL,'0','2017-08-14 22:31:02',NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('55','7','编辑','','sys:role:edit','2','',NULL,NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('56','7','删除','','sys:role:remove','2',NULL,NULL,NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('57','91','运行监控','/druid/index.html','','1','fa fa-caret-square-o-right','1',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('61','2','批量删除','','sys:menu:batchRemove','2',NULL,NULL,NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('62','7','批量删除','','sys:role:batchRemove','2',NULL,NULL,NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('73','3','部门管理','/system/sysDept','system:sysDept:sysDept','1','fa fa-users','3',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('74','73','增加','/system/sysDept/add','system:sysDept:add','2',NULL,'1',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('75','73','刪除','system/sysDept/remove','system:sysDept:remove','2',NULL,'2',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('76','73','编辑','/system/sysDept/edit','system:sysDept:edit','2',NULL,'3',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('84','0','办公管理','','','0','fa fa-laptop','5',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('85','84','通知公告','oa/notify','oa:notify:notify','1','fa fa-pencil-square',NULL,NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('86','85','新增','oa/notify/add','oa:notify:add','2','fa fa-plus','1',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('87','85','编辑','oa/notify/edit','oa:notify:edit','2','fa fa-pencil-square-o','2',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('88','85','删除','oa/notify/remove','oa:notify:remove','2','fa fa-minus',NULL,NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('89','85','批量删除','oa/notify/batchRemove','oa:notify:batchRemove','2','',NULL,NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('90','84','我的通知','oa/notify/selfNotify','','1','fa fa-envelope-square',NULL,NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('91','0','系统监控','','','0','fa fa-video-camera','5',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('92','91','在线用户','sys/online','','1','fa fa-user',NULL,NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('111','0','用户管理','','','0','fa fa-bars',NULL,NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('112','111','用户列表','/platform/user','','1','fa fa-bars',NULL,NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('113','111','用户认证','/platform/user/listAuth','','1','fa fa-bars',NULL,NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('117','111','举报信息','/platform/accusation/accusation','','1','fa fa-bars',NULL,NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('119742490717831168','0','运行管理','','','0','fa fa-anchor','4',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('119742633412247552','119742490717831168','定时任务管理','/common/job','','1','fa fa-calendar','1',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('119744392318795776','3','字典表','/common/dict','common:dict:dict','1','','5',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('119744658048925696','119744392318795776','增加','/common/dict/add','common:dict:dict','2','','1',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('119745179547713536','119744392318795776','修改','/common/dict/edit','common:dict:edit','2','','2',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('119745607198949376','119744392318795776','删除','/common/dict/remove','common:dict:remove','2','','3',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('120092655035170816','120094879719178240','题库管理','/exam/quesBank','','1','','2',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('120092723163250688','120094879719178240','试卷管理','/exam/papersQuesrel','','1','','3',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('120092802817277952','120094879719178240','考生管理','/exam/examineeIndex','','1','','4',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('120092894815141888','120094879719178240','新闻管理','/news/newsIndex','','1','','5',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('120092997718196224','120094879719178240','法律微课堂','/video/videoIndex','','1','','6',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('120093079402266624','120094879719178240','法律法规','/exam/plawIndex','','1','','7',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('120093140542636032','120094879719178240','案例学习','/caseConfig/caseIndex','','1','','8',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('120093234272747520','120094879719178240','问卷管理','/answer/AnswerAskIndex','','1','','9',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('120093310525194240','120094879719178240','学生成绩','/exam/examResultsIndex','','1','','10',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('120093428758429696','120094879719178240','考生用户管理','/exam/accountIndex','','1','','11',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('120094879719178240','0','法律大练兵','','','0','fa fa-bars','1',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('120581665012600832','120094879719178240','测试','/sys/user2','sys:user:user','1','','11',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('120582828759994368','120581665012600832','增加','','sys:user:add','2','','1',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('120583193324703744','120581665012600832','修改','','sys:user:edit','2','','2',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('120583297637044224','120581665012600832','刪除','','sys:user:remove','2','','3',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('124175023457083392','120094879719178240','逮捕标准指引','/guide/videnceIndex','','1','','12',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('124923240331235328','120094879719178240','基本证据清单','/guide/videnceListIndex','','1','','13',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('124923314033545216','120094879719178240','证据标准指引','/guide/standardListIndex','','1','','14',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('124923425778192384','120094879719178240','证据规则指引','/guide/rulesListIndex','','1','','15',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('124923501774786560','120094879719178240','证据链指引','/guide/chainListIndex','','1','','16',NULL,NULL);
insert into `sys_menu` (`menu_id`, `parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`, `gmt_create`, `gmt_modified`) values('125620724875554816','120094879719178240','执法漫画','/picture/pictureIndex','','1','','17',NULL,NULL);



/*
SQLyog Ultimate - MySQL GUI v8.2 
MySQL - 5.5.27 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `sys_role_menu` (
	`id` double ,
	`role_id` double ,
	`menu_id` double 
); 
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3232','59','98');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3233','59','101');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3234','59','99');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3235','59','95');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3236','59','90');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3237','59','89');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3238','59','88');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3239','59','87');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3240','59','86');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3241','59','68');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3242','59','60');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3243','59','59');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3244','59','58');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3245','59','51');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3246','59','76');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3247','59','75');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3248','59','74');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3249','59','62');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3250','59','56');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3251','59','55');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3252','59','15');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3253','59','26');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3254','59','25');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3255','59','24');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3256','59','14');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3257','59','13');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3258','59','12');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3259','59','61');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3260','59','22');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3261','59','21');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3262','59','20');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3263','59','83');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3264','59','81');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3265','59','80');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3266','59','79');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3267','59','71');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3268','59','97');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3269','59','96');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3270','59','94');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3271','59','93');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3272','59','85');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3273','59','84');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3274','59','50');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3275','59','49');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3276','59','73');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3277','59','7');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3278','59','6');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3279','59','2');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3280','59','3');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3281','59','78');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3282','59','1');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('3283','59','-1');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745660890234880','1','119742633412247552');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745660902817792','1','117');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745660915400704','1','113');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745660923789312','1','112');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745660932177920','1','92');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745660944760832','1','57');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745660953149440','1','30');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745660961538048','1','29');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745660969926656','1','28');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745660978315264','1','90');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745660986703872','1','89');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745660995092480','1','88');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661003481088','1','87');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661011869696','1','86');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661020258304','1','76');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661032841216','1','75');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661041229824','1','74');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661049618432','1','62');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661058007040','1','56');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661066395648','1','55');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661078978560','1','15');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661091561472','1','26');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661099950080','1','25');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661108338688','1','24');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661116727296','1','14');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661125115904','1','13');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661137698816','1','12');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661146087424','1','61');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661154476032','1','22');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661162864640','1','21');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661171253248','1','20');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661179641856','1','119742490717831168');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661188030464','1','111');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661196419072','1','27');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661204807680','1','91');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661213196288','1','85');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661221584896','1','84');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661229973504','1','73');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661238362112','1','7');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661246750720','1','6');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661255139328','1','2');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661259333632','1','119744392318795776');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661267722240','1','119745607198949376');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661276110848','1','119745179547713536');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661284499456','1','119744658048925696');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661292888064','1','3');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('119745661301276672','1','-1');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763534454784','2','124923501774786560');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763547037696','2','124923425778192384');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763555426304','2','124923314033545216');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763559620608','2','124923240331235328');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763568009216','2','124175023457083392');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763576397824','2','120583297637044224');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763584786432','2','120583193324703744');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763593175040','2','120582828759994368');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763601563648','2','120093428758429696');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763609952256','2','120093310525194240');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763614146560','2','120093234272747520');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763618340864','2','120093140542636032');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763626729472','2','120093079402266624');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763630923776','2','120092997718196224');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763635118080','2','120092894815141888');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763643506688','2','120092802817277952');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763651895296','2','120092723163250688');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763660283904','2','120092655035170816');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763664478208','2','90');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763698032640','2','89');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763706421248','2','88');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763714809856','2','87');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763727392768','2','86');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763735781376','2','120581665012600832');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763739975680','2','85');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763744169984','2','84');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763752558592','2','125620724875554816');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763756752896','2','120094879719178240');
insert into `sys_role_menu` (`id`, `role_id`, `menu_id`) values('125620763760947200','2','-1');
